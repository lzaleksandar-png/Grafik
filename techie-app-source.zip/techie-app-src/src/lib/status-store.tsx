import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { workDay as defaultDay, type JobStatus, type WorkDay } from "./jobs";

const STORAGE_KEY = "tech-job-status-v1";
const DAY_KEY = "tech-workday-v1";
const WORKED_KEY = "tech-worked-days-v1";
const HISTORY_KEY = "tech-schedule-history-v1";

export type WorkedDays = Record<string, { team: string; jobs: number; hours?: number }>;

/** Saves custom net hours for a worked day (10 = default full day). */
export function setWorkedHours(date: string, hours: number): WorkedDays {
  const days = readWorkedDays();
  if (days[date]) {
    days[date] = { ...days[date], hours };
    localStorage.setItem(WORKED_KEY, JSON.stringify(days));
  }
  return days;
}

const REMOVED_KEY = "tech-removed-days-v1";

function readRemoved(): string[] {
  try {
    return JSON.parse(localStorage.getItem(REMOVED_KEY) ?? "[]") as string[];
  } catch {
    return [];
  }
}

/** Manually marks (or unmarks) a day as worked, for days without an uploaded schedule. */
export function toggleWorkedDay(date: string, worked: boolean): WorkedDays {
  const days = readWorkedDays();
  const removed = readRemoved().filter((d) => d !== date);
  if (worked) days[date] = days[date] ?? { team: "", jobs: 0 };
  else {
    delete days[date];
    removed.push(date); // so the history backfill doesn't re-add it
  }
  localStorage.setItem(REMOVED_KEY, JSON.stringify(removed));
  localStorage.setItem(WORKED_KEY, JSON.stringify(days));
  return days;
}

export function readWorkedDays(): WorkedDays {
  let days: WorkedDays = {};
  try {
    days = JSON.parse(localStorage.getItem(WORKED_KEY) ?? "{}") as WorkedDays;
  } catch {
    days = {};
  }
  try {
    // Merge every uploaded schedule (history + current day) so no day is lost.
    const removed = new Set(readRemoved());
    let changed = false;
    for (const day of Object.values(readScheduleHistoryMap())) {
      if (/^\d{2}\.\d{2}\.\d{4}$/.test(day.date) && !days[day.date] && !removed.has(day.date)) {
        days[day.date] = { team: day.team, jobs: day.jobs?.length ?? 0 };
        changed = true;
      }
    }
    if (changed) localStorage.setItem(WORKED_KEY, JSON.stringify(days));
  } catch {
    /* ignore */
  }
  return days;
}

function readScheduleHistoryMap(): Record<string, WorkDay> {
  try {
    const map = JSON.parse(localStorage.getItem(HISTORY_KEY) ?? "{}") as Record<string, WorkDay>;
    // Schedules uploaded before search existed live only under DAY_KEY.
    const savedDay = localStorage.getItem(DAY_KEY);
    if (savedDay) {
      const day = JSON.parse(savedDay) as WorkDay;
      if (/^\d{2}\.\d{2}\.\d{4}$/.test(day.date) && !map[day.date]) {
        map[day.date] = day;
        localStorage.setItem(HISTORY_KEY, JSON.stringify(map));
      }
    }
    return map;
  } catch {
    return {};
  }
}

/** All schedules ever uploaded on this device, one per date. */
export function readScheduleHistory(): WorkDay[] {
  return Object.values(readScheduleHistoryMap());
}

type Statuses = Record<string, JobStatus>;

const Ctx = createContext<{
  statuses: Statuses;
  setStatus: (id: string, status: JobStatus) => void;
  day: WorkDay;
  setDay: (day: WorkDay) => void;
}>({ statuses: {}, setStatus: () => {}, day: defaultDay, setDay: () => {} });

export function StatusProvider({ children }: { children: ReactNode }) {
  const [statuses, setStatuses] = useState<Statuses>({});
  const [day, setDayState] = useState<WorkDay>(defaultDay);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setStatuses(JSON.parse(raw) as Statuses);
      const d = localStorage.getItem(DAY_KEY);
      if (d) setDayState(JSON.parse(d) as WorkDay);
    } catch {
      /* ignore */
    }
  }, []);

  const setStatus = useCallback((id: string, status: JobStatus) => {
    setStatuses((prev) => {
      const next = { ...prev, [id]: status };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const setDay = useCallback((d: WorkDay) => {
    setDayState(d);
    setStatuses({});
    try {
      localStorage.setItem(DAY_KEY, JSON.stringify(d));
      localStorage.setItem(STORAGE_KEY, "{}");
      const days = readWorkedDays();
      days[d.date] = { ...days[d.date], team: d.team, jobs: d.jobs.length };
      localStorage.setItem(WORKED_KEY, JSON.stringify(days));
      // Keep every uploaded schedule so past addresses stay searchable.
      const hist = readScheduleHistoryMap();
      hist[d.date] = d;
      localStorage.setItem(HISTORY_KEY, JSON.stringify(hist));
      localStorage.setItem(REMOVED_KEY, JSON.stringify(readRemoved().filter((x) => x !== d.date)));
    } catch {
      /* ignore */
    }
  }, []);

  return (
    <Ctx.Provider value={{ statuses, setStatus, day, setDay }}>{children}</Ctx.Provider>
  );
}

export function useStatuses() {
  return useContext(Ctx);
}

export function useWorkDay() {
  return useContext(Ctx).day;
}

export function statusOf(statuses: Statuses, id: string): JobStatus {
  return statuses[id] ?? "open";
}
