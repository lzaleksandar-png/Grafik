export type JobStatus = "open" | "active" | "done" | "blocked";

export type Job = {
  id: string;
  slot: string;
  nvt: string;
  address: string;
  units: number;
  customer: string;
  phone: string;
  ne4: boolean;
  note?: string;
};

export type WorkDay = {
  team: string;
  weekday: string;
  date: string;
  jobs: Job[];
  lunch: string;
};

export const workDay: WorkDay = {
  team: "Екип 1",
  weekday: "Четвъртък",
  date: "24.09.2026",
  lunch: "12:00 - 13:00",
  jobs: [
    {
      id: "1",
      slot: "08:00 - 09:00",
      nvt: "N059",
      address: "Theodor-Heuss-Straße 23",
      units: 1,
      customer: "Familienzentrum",
      phone: "0521333193",
      ne4: true,
      note: "Schwarzes Pipe bitte vom Haus aus Luft geben",
    },
    {
      id: "2",
      slot: "09:00 - 10:00",
      nvt: "N028",
      address: "Eutiner Straße 8",
      units: 1,
      customer: "Ulrich Philipp",
      phone: "01717678038",
      ne4: true,
    },
    {
      id: "3",
      slot: "10:00 - 11:00",
      nvt: "N064",
      address: "Gustav-Bastert-Straße 2",
      units: 19,
      customer: "Herr Krause",
      phone: "0521331531",
      ne4: false,
    },
    {
      id: "4",
      slot: "11:00 - 12:00",
      nvt: "N064",
      address: "Gustav-Bastert-Straße 4",
      units: 14,
      customer: "Herr Krause",
      phone: "0521331531",
      ne4: false,
    },
    {
      id: "5",
      slot: "14:00 - 15:00",
      nvt: "N024",
      address: "Segeberger Straße 20",
      units: 1,
      customer: "BGW, Hr. Alhammoud",
      phone: "01709177530",
      ne4: true,
    },
    {
      id: "6",
      slot: "15:00 - 16:00",
      nvt: "N024",
      address: "Segeberger Straße 22",
      units: 1,
      customer: "BGW, Hr. Alhammoud",
      phone: "01709177530",
      ne4: true,
    },
    {
      id: "7",
      slot: "16:00 - 17:00",
      nvt: "N024",
      address: "Segeberger Straße 24",
      units: 1,
      customer: "BGW, Hr. Alhammoud",
      phone: "01709177530",
      ne4: true,
    },
    {
      id: "8",
      slot: "17:00 - 18:00",
      nvt: "N024",
      address: "Segeberger Straße 21/23",
      units: 1,
      customer: "BGW, Hr. Alhammoud",
      phone: "01709177530",
      ne4: true,
    },
  ],
};

export const statusLabels: Record<JobStatus, string> = {
  open: "Предстои",
  active: "В процес",
  done: "Готово",
  blocked: "Проблем",
};

export const statusOrder: JobStatus[] = ["open", "active", "done", "blocked"];

export function mapsUrl(address: string) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address + ", Bielefeld")}`;
}
