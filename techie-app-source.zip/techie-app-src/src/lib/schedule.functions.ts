import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { WorkDay } from "./jobs";

const Input = z.object({
  image: z.string().startsWith("data:image/").max(15_000_000),
});

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["team", "weekday", "date", "lunch", "jobs"],
  properties: {
    team: { type: "string", description: "Team name in Bulgarian, e.g. 'Екип 1' for TEAM 1" },
    weekday: { type: "string", description: "Weekday translated to Bulgarian, e.g. Mittwoch -> Сряда" },
    date: { type: "string", description: "DD.MM.YYYY" },
    lunch: { type: "string", description: "Lunch break time range like '12:00 - 13:00', or empty" },
    jobs: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["slot", "nvt", "address", "units", "customer", "phone", "ne4", "note"],
        properties: {
          slot: { type: "string", description: "'08:00 - 09:00'" },
          nvt: { type: "string" },
          address: { type: "string" },
          units: { type: "integer", description: "WE count" },
          customer: { type: "string" },
          phone: { type: "string" },
          ne4: { type: "boolean", description: "NE4 / ONT column: ja=true, nein=false" },
          note: { type: "string", description: "Comment, or empty string" },
        },
      },
    },
  },
};

export const parseSchedule = createServerFn({ method: "POST" })
  .inputValidator((d) => Input.parse(d))
  .handler(async ({ data }): Promise<{ ok: true; day: WorkDay } | { ok: false; error: string }> => {
    const key = process.env['LOVABLE_API_KEY'];
    if (!key) return { ok: false, error: "Липсва конфигурация на AI." };
    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        input: [
          {
            role: "user",
            content: [
              {
                type: "input_text",
                text: "This is a photo of a fiber-installation technician's daily schedule table (German). Extract every appointment row exactly (addresses, phone numbers digit by digit). Skip the lunch row from jobs but put its time in 'lunch'.",
              },
              { type: "input_image", image_url: data.image },
            ],
          },
        ],
        text: { format: { type: "json_schema", name: "workday", strict: true, schema } },
      }),
    });
    if (!res.ok) {
      const msg =
        res.status === 402
          ? "Няма достатъчно AI кредити."
          : res.status === 429
            ? "Твърде много заявки — опитай след малко."
            : `Грешка при разчитане (${res.status}).`;
      return { ok: false, error: msg };
    }
    const json = (await res.json()) as {
      output?: { type: string; content?: { type: string; text?: string }[] }[];
    };
    const text = json.output
      ?.flatMap((o) => o.content ?? [])
      .find((c) => c.type === "output_text")?.text;
    if (!text) return { ok: false, error: "Снимката не можа да бъде разчетена." };
    const parsed = JSON.parse(text) as Omit<WorkDay, "jobs"> & {
      jobs: (Omit<WorkDay["jobs"][number], "id"> & { note: string })[];
    };
    if (!parsed.jobs.length) return { ok: false, error: "Не бяха открити задачи на снимката." };
    return {
      ok: true,
      day: {
        ...parsed,
        jobs: parsed.jobs.map(({ note, ...j }, i) => ({ ...j, id: String(i + 1), ...(note ? { note } : {}) })),
      },
    };
  });
