import type { WorkedDays } from "@/lib/status-store";

const MONTHS_DE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
const EMPLOYEE = "Aleksandar Aleksandrov";
const PROJECT = "Bielefeld / Heepen";
const pad = (n: number) => String(n).padStart(2, "0");

/** Monthly "Dokumentation der täglichen Arbeitszeiten" — 08:00–19:00, 1h pause, 10,0 h per worked day. */
export async function downloadTimesheet(y: number, m: number, worked: WorkedDays) {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const daysIn = new Date(y, m + 1, 0).getDate();
  let days = 0;
  let hours = 0;
  const hhmm = (h: number) => `${pad(Math.floor(h))}:${pad(Math.round((h % 1) * 60))}`;
  const body = Array.from({ length: daysIn }, (_, i) => {
    const d = i + 1;
    const w = worked[`${pad(d)}.${pad(m + 1)}.${y}`];
    if (!w) return [`${d}.`, "", "", "", "", "", ""];
    const h = w.hours ?? 10;
    days++;
    hours += h;
    // Start 08:00; days over 5 h include the 13:00–14:00 break.
    const withPause = h > 5;
    const end = 8 + h + (withPause ? 1 : 0);
    return [`${d}.`, "08:00", withPause ? "13:00 - 14:00" : "-", hhmm(end), h.toFixed(1).replace(".", ","), PROJECT, ""];
  });

  // Company header band (navy), matching the B2Projects template
  doc.setFillColor(27, 58, 107).rect(14, 6, 182, 15, "F");
  doc.setTextColor(255);
  doc.setFont("helvetica", "bold").setFontSize(14);
  doc.text("B2Projects GmbH & Co. KG", 18, 12.5);
  doc.setFont("helvetica", "normal").setFontSize(8);
  doc.text("Dokumentation der täglichen Arbeitszeiten", 18, 17.5);
  doc.setFont("helvetica", "bold").setFontSize(22);
  doc.text("B2", 192, 15, { align: "right" });
  doc.setTextColor(0);
  doc.setFontSize(10).setFont("helvetica", "normal");
  doc.text("Mitarbeiter:", 14, 27);
  doc.text("Monat:", 100, 27);
  doc.setFont("helvetica", "bold");
  doc.text(EMPLOYEE, 34, 27);
  doc.text(`${MONTHS_DE[m]} ${y}`, 113, 27);

  autoTable(doc, {
    startY: 30,
    head: [["Tag", "Beginn (Uhrzeit)", "Pause (Dauer von bis)", "Ende (Uhrzeit)", "Arbeitszeit (Summe)", "Projekte", "Bemerkungen"]],
    body,
    theme: "grid",
    styles: { fontSize: 8, cellPadding: 1.1, halign: "center", lineColor: 0, lineWidth: 0.2, textColor: 0 },
    headStyles: { fillColor: [220, 220, 220], textColor: 0, fontStyle: "bold" },
    columnStyles: { 1: { fontStyle: "bold" }, 2: { fontStyle: "bold" }, 3: { fontStyle: "bold" }, 4: { fontStyle: "bold" } },
    margin: { left: 14, right: 14 },
  });

  let yy = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;
  doc.setFont("helvetica", "bold").setFontSize(11);
  doc.text(`Summe: ${hours.toFixed(1).replace(".", ",")} Stunden / ${days} Tage`, 196, yy, { align: "right" });
  yy += 12;
  doc.setFont("helvetica", "normal").setFontSize(9);
  doc.text("Datum: ____________________", 14, yy);
  doc.text("Unterschrift Mitarbeiter: ____________________", 100, yy);
  yy += 9;
  doc.text("Datum: ____________________", 14, yy);
  doc.text("Unterschrift Bauleiter: ____________________", 100, yy);
  yy += 10;
  doc.setFont("helvetica", "bold").text("Arbeitszeit-Regelung:", 14, yy);
  doc.setFont("helvetica", "normal").text(
    "Montag - Freitag: 08:00 - 19:00 Uhr | Pause: 13:00 - 14:00 Uhr (1 Std.) | Netto-Arbeitszeit: 10,0 Std./Tag",
    14, yy + 5,
  );

  doc.save(`Arbeitszeiten_${EMPLOYEE.replace(" ", "_")}_${MONTHS_DE[m]}_${y}.pdf`);
}
