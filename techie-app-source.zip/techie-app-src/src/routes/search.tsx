import { createFileRoute } from "@tanstack/react-router";
import {
  CalendarDays,
  Check,
  Copy,
  Navigation,
  Phone,
  Search as SearchIcon,
  Wrench,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { mapsUrl, type Job, type WorkDay } from "@/lib/jobs";
import { readScheduleHistory } from "@/lib/status-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Търсене — минали адреси" },
      {
        name: "description",
        content: "Търсене по качените графици: адреси, клиенти, телефони и NVT.",
      },
      { property: "og:title", content: "Търсене — минали адреси" },
      {
        property: "og:description",
        content: "Търсене по качените графици: адреси, клиенти, телефони и NVT.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SearchPage,
});

function norm(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function jobText(j: Job) {
  return norm(`${j.slot} ${j.address} ${j.customer} ${j.nvt} ${j.phone} ${j.note ?? ""}`);
}

function dateKey(d: string) {
  const [dd, mm, yyyy] = d.split(".");
  return `${yyyy}${mm}${dd}`;
}

function SearchPage() {
  const [days, setDays] = useState<WorkDay[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    setDays(
      readScheduleHistory().filter(
        (d) => /^\d{2}\.\d{2}\.\d{4}$/.test(d.date) && Array.isArray(d.jobs),
      ),
    );
  }, []);

  const query = norm(q.trim());

  const results = useMemo(() => {
    if (!query) return [];
    const tokens = query.split(/\s+/).filter(Boolean);
    return days
      .slice()
      .sort((a, b) => dateKey(b.date).localeCompare(dateKey(a.date)))
      .map((day) => ({
        day,
        jobs: day.jobs.filter((j) => {
          const t = jobText(j);
          return tokens.every((tok) => t.includes(tok));
        }),
      }))
      .filter((r) => r.jobs.length > 0);
  }, [days, query]);

  const totalDays = days.length;

  return (
    <div className="mx-auto max-w-xl px-3 pb-16 pt-5">
      <header className="mb-4 px-1">
        <p className="text-lg font-bold tracking-tight">Търсене</p>
        <p className="text-xs text-muted-foreground">
          {totalDays > 0
            ? `Запазени графици на този телефон: ${totalDays}`
            : "Още няма запазени графици на този телефон."}
        </p>
      </header>

      <div className="relative mb-4">
        <SearchIcon className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Адрес, клиент, телефон, NVT…"
          aria-label="Търсене на адреси"
          className="w-full rounded-full border border-border bg-card py-2.5 pl-10 pr-4 text-sm outline-none placeholder:text-muted-foreground focus:border-primary"
        />
      </div>

      {!query ? (
        <div className="rounded-2xl border border-dashed border-border bg-card px-4 py-6 text-center text-sm text-muted-foreground">
          <CalendarDays className="mx-auto mb-2 size-6 text-muted-foreground/60" />
          Пиши улица, име, телефон или NVT —
          <br />
          търси във всички качени графици.
        </div>
      ) : results.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card px-4 py-6 text-center text-sm text-muted-foreground">
          Няма нищо намерено за „{q.trim()}“.
        </div>
      ) : (
        results.map(({ day, jobs }) => (
          <section key={day.date} className="mb-4">
            <p className="mb-1.5 px-1 text-xs font-semibold text-muted-foreground">
              {day.weekday}, {day.date}
            </p>
            <ol className="space-y-2">
              {jobs.map((job) => (
                <li key={`${day.date}-${job.id}`}>
                  <ResultCard job={job} />
                </li>
              ))}
            </ol>
          </section>
        ))
      )}
    </div>
  );
}

function ResultCard({ job }: { job: Job }) {
  return (
    <div className="rounded-2xl border border-border border-l-4 border-l-primary bg-card shadow-sm">
      <div className="px-3 py-2.5">
        <p className="text-xs font-semibold">
          {job.slot} <span className="ml-1 font-normal text-muted-foreground">{job.nvt}</span>
        </p>
        <p className="mt-0.5 break-words text-[15px] font-bold leading-snug text-foreground">
          {job.address}
        </p>
        <p className="text-xs font-bold text-foreground">{job.customer}</p>
        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
          <span
            className={cn(
              "inline-flex items-center rounded-full px-2 py-0.5 font-bold",
              job.units !== 1
                ? "bg-primary text-primary-foreground text-xs"
                : "bg-accent text-accent-foreground text-[11px]",
            )}
          >
            WE{job.units}
          </span>
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold",
              job.ne4 ? "bg-accent/15 text-accent" : "bg-muted text-muted-foreground",
            )}
          >
            {job.ne4 ? (
              <>
                <Wrench className="size-3" /> ONT: да
              </>
            ) : (
              "ONT: не"
            )}
          </span>
          {job.note && (
            <span className="inline-flex max-w-full items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-semibold text-amber-800">
              <span className="truncate">{job.note}</span>
            </span>
          )}
        </div>
        <div className="mt-2.5 flex items-center gap-2">
          <a
            href={mapsUrl(job.address)}
            target="_blank"
            rel="noreferrer"
            className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground"
          >
            <Navigation className="size-3.5" /> Навигация
          </a>
          <a
            href={`tel:${job.phone}`}
            className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs font-medium"
          >
            <Phone className="size-3.5" /> Обаждане
          </a>
          <CopyButton text={job.address} />
        </div>
      </div>
    </div>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  };

  return (
    <button
      type="button"
      onClick={copy}
      aria-label="Копирай адреса"
      className={cn(
        "inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border px-3 py-2 text-xs font-medium transition-colors",
        copied ? "border-accent bg-accent text-accent-foreground" : "border-border",
      )}
    >
      {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
      {copied ? "Копирано" : "Копирай"}
    </button>
  );
}
