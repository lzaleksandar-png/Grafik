import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Navigation, Phone } from "lucide-react";

import { StatusPicker } from "@/components/StatusPicker";
import { mapsUrl } from "@/lib/jobs";
import { statusOf, useStatuses } from "@/lib/status-store";

export const Route = createFileRoute("/job/$jobId")({
  head: () => ({
    meta: [
      { title: "Детайли по задача — Техник" },
      {
        name: "description",
        content: "Адрес, контакт, NVT, брой жилища и промяна на статуса на задачата.",
      },
      { property: "og:title", content: "Детайли по задача — Техник" },
      {
        property: "og:description",
        content: "Адрес, контакт, NVT, брой жилища и промяна на статуса на задачата.",
      },
    ],
  }),
  component: JobDetail,
});

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border py-2.5 last:border-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}

function JobDetail() {
  const { jobId } = Route.useParams();
  const { statuses, setStatus, day: workDay } = useStatuses();
  const job = workDay.jobs.find((j) => j.id === jobId);

  if (!job) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <p className="text-lg font-semibold">Задачата не е намерена.</p>
        <Link to="/" className="mt-4 inline-block text-primary">
          Към маршрута
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 pb-16 pt-6">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
        <ArrowLeft className="size-4" /> Маршрут
      </Link>

      <p className="mt-6 font-mono text-sm font-semibold text-primary">{job.slot}</p>
      <h1 className="text-2xl font-bold leading-tight">{job.address}</h1>
      <p className="font-semibold text-foreground">{job.customer}</p>

      <div className="mt-5 flex flex-wrap gap-2">
        <a
          href={mapsUrl(job.address)}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"
        >
          <Navigation className="size-4" /> Навигация
        </a>
        <a
          href={`tel:${job.phone}`}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border px-4 py-2.5 text-sm font-medium"
        >
          <Phone className="size-4" /> Обаждане
        </a>
      </div>

      <section className="mt-7 rounded-xl border border-border bg-card p-4">
        <Row label="NVT" value={job.nvt} />
        <Row label="WE (жилища)" value={`${job.units} — ONT: ${job.ne4 ? "да" : "не"}`} />
        <Row label="Телефон" value={job.phone} />
        <Row label="Монтаж на ONT" value={job.ne4 ? "да" : "не"} />
        <Row label="Екип" value={`${workDay.team} · ${workDay.date}`} />
      </section>

      {job.note && (
        <section className="mt-4 rounded-xl border border-border bg-muted/40 p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Коментар
          </p>
          <p className="mt-1.5">{job.note}</p>
        </section>
      )}

      <section className="mt-7">
        <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Статус
        </p>
        <StatusPicker
          value={statusOf(statuses, job.id)}
          onChange={(s) => setStatus(job.id, s)}
        />
      </section>
    </div>
  );
}
