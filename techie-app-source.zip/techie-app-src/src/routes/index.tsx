import { createFileRoute } from "@tanstack/react-router";
import {
  Check,
  ChevronDown,
  Copy,
  Navigation,
  Phone,
  StickyNote,
  UtensilsCrossed,
  Wrench,
} from "lucide-react";
import { useState } from "react";

import { UploadSchedule } from "@/components/UploadSchedule";
import { mapsUrl, type Job } from "@/lib/jobs";
import { statusOf, useStatuses, useWorkDay } from "@/lib/status-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Термине — Екип 1" },
      {
        name: "description",
        content: "Дневен график на техника: часови слотове, адреси, контакти и статус на всяка задача.",
      },
      { property: "og:title", content: "Термине — Екип 1" },
      {
        property: "og:description",
        content: "Дневен график на техника: часови слотове, адреси, контакти и статус на всяка задача.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function Index() {
  const { statuses } = useStatuses();
  const workDay = useWorkDay();
  const lunchStart = workDay.lunch.slice(0, 5);
  const lunchIdx = lunchStart ? workDay.jobs.findIndex((j) => j.slot.slice(0, 5) >= lunchStart) : -1;

  const done = workDay.jobs.filter((j) => statusOf(statuses, j.id) === "done").length;
  const total = workDay.jobs.length;

  return (
    <div className="mx-auto max-w-xl px-3 pb-16 pt-5">
      <header className="mb-4 px-1">
        <p className="text-lg font-bold tracking-tight">
          {workDay.weekday}, {workDay.date}
        </p>
      </header>

      <UploadSchedule />

      <div className="mb-4 rounded-2xl border border-border bg-card px-4 py-3 shadow-sm">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            {done}/{total} завършени
          </span>
          <span className="font-semibold">{total.toFixed(1)} ч</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-primary transition-all"
            style={{ width: `${total ? (done / total) * 100 : 0}%` }}
          />
        </div>
      </div>

      <ol className="space-y-3">
        {workDay.jobs.map((job, i) => (
          <li key={job.id}>
            {workDay.lunch && i === lunchIdx && (
              <div className="mb-3 flex items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-amber-400 bg-amber-50 px-3 py-2.5 text-sm font-semibold text-amber-800">
                <UtensilsCrossed className="size-4" />
                Обедна почивка · {workDay.lunch}
              </div>
            )}
            <JobCard job={job} />
          </li>
        ))}
      </ol>
    </div>
  );
}

function JobCard({ job }: { job: Job }) {
  const { statuses, setStatus } = useStatuses();
  const status = statusOf(statuses, job.id);
  const isDone = status === "done";
  const [open, setOpen] = useState(false);

  return (
    <div
      className={cn(
        "rounded-2xl border border-border border-l-4 border-l-primary bg-card shadow-sm",
        isDone && "opacity-60",
      )}
    >
      {/* Collapsed: time, address, WE — always visible */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-start gap-2.5 rounded-2xl px-3 py-2.5 text-left"
      >
        <span
          role="checkbox"
          aria-checked={isDone}
          aria-label={isDone ? "Отбележи като незавършена" : "Отбележи като готово"}
          onClick={(e) => {
            e.stopPropagation();
            setStatus(job.id, isDone ? "open" : "done");
          }}
          className={cn(
            "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full border-2 transition-colors",
            isDone
              ? "border-accent bg-accent text-accent-foreground"
              : "border-muted-foreground/40 bg-transparent",
          )}
        >
          {isDone && <Check className="size-4" strokeWidth={3} />}
        </span>

        <div className="min-w-0 flex-1">
          <p className="text-xs font-semibold">
            {job.slot} <span className="ml-1 font-normal text-muted-foreground">{job.nvt}</span>
          </p>
          <p
            className={cn(
              "mt-0.5 text-[15px] font-bold leading-snug break-words",
              isDone && "line-through",
            )}
          >
            {job.address}
          </p>
          <p className="text-xs font-bold text-foreground">{job.customer}</p>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <span className={cn(
              "inline-flex items-center rounded-full px-2 py-0.5 font-bold",
              job.units !== 1
                ? "bg-primary text-primary-foreground text-xs"
                : "bg-accent text-accent-foreground text-[11px]",
            )}>
              WE{job.units}
            </span>
            <span
              className={cn(
                "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold",
                job.ne4 ? "bg-accent/15 text-accent" : "bg-muted text-muted-foreground",
              )}
            >
              {job.ne4 ? (
                <>
                  <Wrench className="size-3" /> ONT: да
                </>
              ) : (
                "ONT: не"
              )}
            </span>
            {job.note && (
              <span className="inline-flex max-w-full items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-semibold text-amber-800">
                <StickyNote className="size-3 shrink-0" />
                <span className="truncate">{job.note}</span>
              </span>
            )}
          </div>
        </div>

        <ChevronDown
          className={cn(
            "mt-1 size-5 shrink-0 text-muted-foreground transition-transform",
            open && "rotate-180",
          )}
        />
      </button>

      {/* Expanded submenu */}
      {open && (
        <div className="space-y-3 border-t border-border px-4 pb-4 pt-3">
          <dl className="space-y-1.5 text-sm">
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">WE (жилища)</dt>
              <dd className="font-semibold">{job.units}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">Монтаж на ONT</dt>
              <dd className="font-semibold">{job.ne4 ? "да" : "не"}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">NVT</dt>
              <dd className="font-semibold">{job.nvt}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">Телефон</dt>
              <dd className="font-semibold">
                <a href={`tel:${job.phone}`} className="text-primary">
                  {job.phone}
                </a>
              </dd>
            </div>
          </dl>

          {job.note && (
            <p className="inline-flex items-center gap-1.5 rounded-full border border-border bg-muted px-2.5 py-1 text-xs text-muted-foreground">
              <StickyNote className="size-3.5" /> {job.note}
            </p>
          )}

          <div className="flex items-center gap-2">
            <a
              href={mapsUrl(job.address)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground"
            >
              <Navigation className="size-3.5" /> Навигация
            </a>
            <a
              href={`tel:${job.phone}`}
              className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs font-medium"
            >
              <Phone className="size-3.5" /> Обаждане
            </a>
            <CopyAddressButton address={job.address} />
          </div>
        </div>
      )}
    </div>
  );
}

function CopyAddressButton({ address }: { address: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(address);
    } catch {
      // Fallback за по-стари браузъри без Clipboard API
      const el = document.createElement("textarea");
      el.value = address;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  };

  return (
    <button
      type="button"
      onClick={copy}
      aria-label="Копирай адреса"
      className={cn(
        "inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border px-3 py-2 text-xs font-medium transition-colors",
        copied
          ? "border-accent bg-accent text-accent-foreground"
          : "border-border",
      )}
    >
      {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
      {copied ? "Копирано" : "Копирай"}
    </button>
  );
}
