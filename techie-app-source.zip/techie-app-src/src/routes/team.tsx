import { createFileRoute } from "@tanstack/react-router";

import { StatusBadge } from "@/components/StatusBadge";
import { statusLabels, statusOrder, type JobStatus } from "@/lib/jobs";
import { statusOf, useStatuses } from "@/lib/status-store";

export const Route = createFileRoute("/team")({
  head: () => ({
    meta: [
      { title: "Екип и напредък — Техник" },
      {
        name: "description",
        content: "Обобщение за деня: колко задачи са готови, в процес, предстоящи или с проблем.",
      },
      { property: "og:title", content: "Екип и напредък — Техник" },
      {
        property: "og:description",
        content: "Обобщение за деня: колко задачи са готови, в процес, предстоящи или с проблем.",
      },
    ],
  }),
  component: TeamPage,
});

function TeamPage() {
  const { statuses, day: workDay } = useStatuses();
  const total = workDay.jobs.length;
  const done = workDay.jobs.filter((j) => statusOf(statuses, j.id) === "done").length;
  const pct = Math.round((done / total) * 100);

  const counts = statusOrder.reduce(
    (acc, s) => {
      acc[s] = workDay.jobs.filter((j) => statusOf(statuses, j.id) === s).length;
      return acc;
    },
    {} as Record<JobStatus, number>,
  );

  return (
    <div className="mx-auto max-w-3xl px-4 pb-16 pt-6">
      <h1 className="text-3xl font-bold tracking-tight">{workDay.team}</h1>
      <p className="text-muted-foreground">
        {workDay.weekday}, {workDay.date}
      </p>

      <div className="mt-6 rounded-xl border border-border bg-card p-4">
        <div className="flex items-end justify-between">
          <span className="text-sm text-muted-foreground">Изпълнени задачи</span>
          <span className="font-mono text-2xl font-semibold">
            {done}/{total}
          </span>
        </div>
        <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-muted">
          <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {statusOrder.map((s) => (
          <div key={s} className="rounded-xl border border-border bg-card p-4">
            <p className="font-mono text-2xl font-semibold">{counts[s]}</p>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">
              {statusLabels[s]}
            </p>
          </div>
        ))}
      </div>

      <h2 className="mt-8 text-lg font-semibold">Всички задачи за деня</h2>
      <ul className="mt-3 divide-y divide-border rounded-xl border border-border bg-card">
        {workDay.jobs.map((job) => (
          <li key={job.id} className="flex items-center justify-between gap-3 px-4 py-3">
            <div>
              <p className="font-mono text-xs text-primary">{job.slot}</p>
              <p className="font-medium">{job.address}</p>
            </div>
            <StatusBadge status={statusOf(statuses, job.id)} />
          </li>
        ))}
      </ul>
    </div>
  );
}
