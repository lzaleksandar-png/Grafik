import { createFileRoute } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, FileDown } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { readWorkedDays, setWorkedHours, toggleWorkedDay, type WorkedDays } from "@/lib/status-store";
import { downloadTimesheet } from "@/lib/timesheet-pdf";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/calendar")({
  head: () => ({
    meta: [
      { title: "Календар — отработени дни" },
      { name: "description", content: "Календар с дните, в които си бил на работа, според качените графици." },
      { property: "og:title", content: "Календар — отработени дни" },
      { property: "og:description", content: "Календар с дните, в които си бил на работа, според качените графици." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CalendarPage,
});

const MONTHS = ["Януари", "Февруари", "Март", "Април", "Май", "Юни", "Юли", "Август", "Септември", "Октомври", "Ноември", "Декември"];
const WD = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд"];
function latestKey(days: WorkedDays) {
  return Object.keys(days).filter((k) => /^\d{2}\.\d{2}\.\d{4}$/.test(k))
    .sort((a, b) => `${a.slice(6)}${a.slice(3, 5)}${a.slice(0, 2)}`.localeCompare(`${b.slice(6)}${b.slice(3, 5)}${b.slice(0, 2)}`))
    .at(-1);
}
const pad = (n: number) => String(n).padStart(2, "0");

function CalendarPage() {
  const [worked, setWorked] = useState<WorkedDays>({});
  const [selected, setSelected] = useState<string | null>(null);
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return { y: d.getFullYear(), m: d.getMonth() };
  });
  useEffect(() => {
    const days = readWorkedDays();
    setWorked(days);
    // Show the last uploaded work month first, even when viewing the calendar later.
    const latest = latestKey(days);
    if (latest) setCursor({ y: Number(latest.slice(6)), m: Number(latest.slice(3, 5)) - 1 });
  }, []);

  const { y, m } = cursor;
  const first = (new Date(y, m, 1).getDay() + 6) % 7;
  const daysIn = new Date(y, m + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: daysIn }, (_, i) => i + 1)];
  const key = (d: number) => `${pad(d)}.${pad(m + 1)}.${y}`;
  const monthKeys = Array.from({ length: daysIn }, (_, i) => key(i + 1)).filter((k) => worked[k]);
  const monthCount = monthKeys.length;
  const monthHours = monthKeys.reduce((s, k) => s + (worked[k]?.hours ?? 10), 0);
  const total = Object.keys(worked).length;

  const shift = (delta: number) =>
    setCursor(({ y, m }) => {
      const d = new Date(y, m + delta, 1);
      return { y: d.getFullYear(), m: d.getMonth() };
    });

  return (
    <div className="mx-auto max-w-xl px-3 pb-16 pt-5">
      <h1 className="px-1 text-2xl font-bold tracking-tight">Отработени дни</h1>
      <p className="mt-0.5 px-1 text-sm text-muted-foreground">
        Отбелязват се автоматично при качване на график
      </p>

      {monthCount === 0 && total > 0 && (() => {
        const l = latestKey(worked)!;
        return (
          <div className="mt-4 rounded-2xl border border-primary/30 bg-primary/10 p-3 text-sm">
            <p>Няма дни през {MONTHS[m]}. Записани общо: <b>{total}</b> дни.</p>
            <Button type="button" size="sm" className="mt-2 w-full" onClick={() => setCursor({ y: Number(l.slice(6)), m: Number(l.slice(3, 5)) - 1 })}>
              Към {MONTHS[Number(l.slice(3, 5)) - 1]} {l.slice(6)}
            </Button>
          </div>
        );
      })()}

      <div className="mt-4 rounded-2xl border border-border bg-card p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between">
          <Button variant="ghost" size="icon" type="button" onClick={() => shift(-1)} aria-label="Предишен месец">
            <ChevronLeft className="size-5" />
          </Button>
          <p className="font-semibold">
            {MONTHS[m]} {y}
          </p>
          <Button variant="ghost" size="icon" type="button" onClick={() => shift(1)} aria-label="Следващ месец">
            <ChevronRight className="size-5" />
          </Button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-xs text-muted-foreground">
          {WD.map((w) => (
            <div key={w} className="py-1 font-medium">{w}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((d, i) =>
            d === null ? (
              <div key={i} />
            ) : (
              <button
                type="button"
                key={i}
                onClick={() => setSelected(key(d))}
                className={cn(
                  "relative flex aspect-square flex-col items-center justify-center rounded-xl text-sm",
                  worked[key(d)] ? "bg-accent font-bold text-accent-foreground" : "text-foreground",
                  selected === key(d) && "ring-2 ring-primary ring-offset-1",
                )}
              >
                {d}
                {worked[key(d)] && (worked[key(d)]?.hours ?? 10) !== 10 && (
                  <span className="text-[10px] font-semibold leading-none">{worked[key(d)]?.hours}ч</span>
                )}
              </button>
            ),
          )}
        </div>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          Натисни ден, за да го отбележиш или да промениш часовете
        </p>
      </div>

      {selected && !worked[selected] && (
        <div className="mt-4 rounded-2xl border border-border bg-card p-4 shadow-sm">
          <p className="text-sm font-semibold">{selected} — не е отбелязан</p>
          <Button
            type="button"
            className="mt-3 w-full"
            onClick={() => setWorked({ ...toggleWorkedDay(selected, true) })}
          >
            Отбележи като работен ден
          </Button>
        </div>
      )}

      {selected && worked[selected] && (
        <div className="mt-4 rounded-2xl border border-border bg-card p-4 shadow-sm">
          <p className="text-sm font-semibold">Часове за {selected}</p>
          <div className="mt-3 grid grid-cols-6 gap-2">
            {[5, 6, 7, 8, 9, 10].map((h) => (
              <Button
                key={h}
                type="button"
                variant={(worked[selected]?.hours ?? 10) === h ? "default" : "outline"}
                onClick={() => setWorked({ ...setWorkedHours(selected, h) })}
              >
                {h}
              </Button>
            ))}
          </div>
          <div className="mt-2 grid grid-cols-6 gap-2">
            {[5.5, 6.5, 7.5, 8.5, 9.5].map((h) => (
              <Button
                key={h}
                type="button"
                size="sm"
                variant={worked[selected]?.hours === h ? "default" : "outline"}
                onClick={() => setWorked({ ...setWorkedHours(selected, h) })}
              >
                {String(h).replace(".", ",")}
              </Button>
            ))}
          </div>
          <Button
            type="button"
            variant="ghost"
            className="mt-3 w-full text-destructive"
            onClick={() => setWorked({ ...toggleWorkedDay(selected, false) })}
          >
            Премахни работния ден
          </Button>
        </div>
      )}

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-border bg-card p-4 text-center shadow-sm">
          <p className="text-2xl font-bold">{monthCount}</p>
          <p className="text-xs text-muted-foreground">дни този месец</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-4 text-center shadow-sm">
          <p className="text-2xl font-bold">{total}</p>
          <p className="text-xs text-muted-foreground">дни общо</p>
        </div>
      </div>

      <Button
        type="button"
        className="mt-4 h-12 w-full rounded-2xl text-base"
        onClick={() => downloadTimesheet(y, m, worked)}
      >
        <FileDown className="size-5" /> PDF отчет за {MONTHS[m]} ({String(monthHours).replace(".", ",")} ч)
      </Button>
    </div>
  );
}
