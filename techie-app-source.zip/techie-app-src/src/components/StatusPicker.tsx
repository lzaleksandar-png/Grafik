import { statusLabels, statusOrder, type JobStatus } from "@/lib/jobs";
import { cn } from "@/lib/utils";

export function StatusPicker({
  value,
  onChange,
}: {
  value: JobStatus;
  onChange: (s: JobStatus) => void;
}) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      {statusOrder.map((s) => (
        <button
          key={s}
          type="button"
          onClick={() => onChange(s)}
          className={cn(
            "rounded-lg border px-3 py-3 text-sm font-semibold uppercase tracking-wide transition-colors",
            value === s
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground",
          )}
        >
          {statusLabels[s]}
        </button>
      ))}
    </div>
  );
}
