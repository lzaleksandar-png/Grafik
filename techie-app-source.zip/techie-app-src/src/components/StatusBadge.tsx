import { statusLabels, type JobStatus } from "@/lib/jobs";
import { cn } from "@/lib/utils";

const styles: Record<JobStatus, string> = {
  open: "bg-muted text-muted-foreground border-border",
  active: "bg-primary/15 text-primary border-primary/40",
  done: "bg-accent/15 text-accent border-accent/40",
  blocked: "bg-destructive/15 text-destructive border-destructive/40",
};

export function StatusBadge({ status, className }: { status: JobStatus; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider",
        styles[status],
        className,
      )}
    >
      {statusLabels[status]}
    </span>
  );
}
